clear;
clc;

%%%%%%%%%%L1~10%%%%%%%%%%
L1=1;
L2=5.6;
L3=4.3;
L4=4.5;
L5=8.0;

%%%%%%%%%%angle0~5%%%%%%%%%%
angle0=0;
angle1=0:0.001:2*pi;


%to solve the first 4-bar system
Z=L4*exp(i*(pi-angle0))+L1*exp(i*angle1);
temp=Z.*conj(Z)+L2^2-L3^2;
angle2=[ones(1,6284)];

    %solve for angle2
temp2_1=angle((-temp-(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2));
temp2_2=angle((-temp+(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2));
for n=1:6284
    if(temp2_1(n)>0)
        angle2(n)=temp2_1(n);
    else
        angle2(n)=temp2_2(n);
    end
end


    %solve for angle3
angle3=[ones(1,6284)];
temp3_1=angle((Z+L2*(-temp-(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2))/L3);
temp3_2=angle((Z+L2*(-temp+(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2))/L3);
for n=1:6284
    if(temp3_1(n)>0)
        angle3(n)=temp3_1(n);
    else
        angle3(n)=temp3_2(n);
    end
end

%%%%%%%%%%A,B,C,D,E,F,G,H%%%%%%%%%%
A=0;
B=A-L4*exp(i*angle0);
C=L1*exp(i*(pi-angle1));
D=L3*exp(i*(pi-angle3))+B;
G=C+L5*exp(i*(pi-angle2));

%plot(real(G),imag(G)),axis([-25 0 0 25]);
%figure;
%plot(real(H),imag(H)),axis([-70 -40 80 110]);

%%%%%%%%%%Force Analysis%%%%%%%%%%
M=1;
N=0.25*9.8*M;

T=2.3;

f=[ones(1,6284)];
Fa=[ones(1,6284)];
Fb=[ones(1,6284)];
for n=1:6284
    MatrixA=[0 sin(pi+angle1(n)) sin(pi+angle3(n));
             1 cos(pi+angle1(n)) cos(pi+angle3(n));
             0 sin(angle1(n)-angle2(n))*L5 sin(angle3(n)-angle2(n))*(L5-L2);];
    MatrixB=[-N-T*sin(pi/2+angle1(n))/L1;
             -T*cos(pi/2+angle1(n))/L1;
             -T*sin(angle1(n)-pi/2-angle2(n))*L5/L1];
    MatrixC=inv(MatrixA)*MatrixB;
    f(n)=MatrixC(1);
    Fa(n)=MatrixC(2);
    Fb(n)=MatrixC(3);
end

plot(f),axis([0 6284 0 20])