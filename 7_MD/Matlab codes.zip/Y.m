clear;
clc;

%%%%%%%%%%L1~10%%%%%%%%%%
L1=5.27;
L2=18.86;
L3=18.19;
L4=18.1;
L5=39.6;
L6=33.14;
L7=22.2;
L8=65;
L9=2.02;
L10=14.38;

%%%%%%%%%%angle0~5%%%%%%%%%%
angle0=2*pi*31.58/360;
angle1=0:0.001:2*pi;


%to solve the first 4-bar system
Z=L4*exp(i*(pi-angle0))+L1*exp(i*angle1);
temp=Z.*conj(Z)+L2^2-L3^2;
angle2=[ones(1,6284)];

    %solve for angle2
temp2_1=angle((-temp-(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2));
temp2_2=angle((-temp+(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2));
for n=1:6284
    if(temp2_1(n)>0)
        angle2(n)=temp2_1(n);
    else
        angle2(n)=temp2_2(n);
    end
end


    %solve for angle3
angle3=[ones(1,6284)];
temp3_1=angle((Z+L2*(-temp-(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2))/L3);
temp3_2=angle((Z+L2*(-temp+(temp.^2-4*L2^2*Z.*conj(Z)).^(0.5))./(2*conj(Z)*L2))/L3);
for n=1:6284
    if(temp3_1(n)>0)
        angle3(n)=temp3_1(n);
    else
        angle3(n)=temp3_2(n);
    end
end

%%%%%%%%%%A,B,C,D,E,F,G,H%%%%%%%%%%
A=0;
B=A-L4*exp(i*angle0);
C=L1*exp(i*(pi-angle1));
D=L3*exp(i*(pi-angle3))+B;
E=A-L9+i*L10;
G=C+L5*exp(i*(pi-angle2));

    %solve for F & G
L_EG=abs(G-E);
angle_FEG=acos((L6^2+L_EG.^2-L7^2)./(2*L6*L_EG));
angle_EG=angle(G-E);
angle4=[ones(1,6284)];
for n=1:6284
    if(angle_EG(n)>0)
        angle4(n)=pi+angle_FEG(n)-angle_EG(n);
    else
        angle4(n)=pi+angle_FEG(n)-(angle_EG(n)+2*pi);
    end
end

F=E+L6*exp(i*(pi-angle4));
angle5=pi-angle(F-G);
H=F+L8*exp(i*angle5);

%plot(real(D),imag(D)),axis([-25 0 0 25]);
%figure;
%plot(real(H),imag(H)),axis([-70 -40 80 110]);

%%%%%%%%%%Force Analysis%%%%%%%%%%
M=100;
N=0.25*9.8*M;

T=10*M;

sto=sin(-angle4).*imag(G-F)+cos(-angle4).*real(G-F);
f=[ones(1,6284)];
F4=[ones(1,6284)];
F3=[ones(1,6284)];
F1=[ones(1,6284)];
for n=1:6284
    MatrixA=[0 sin(-angle4(n)) sin(-angle3(n))                       sin(-angle1(n));
       -1      cos(angle4(n))  cos(angle3(n))                        cos(angle1(n));
       imag(G(n)-H(n)) sto(n)  0                                     0;
       0       0               cos(pi/2+angle2(n)-angle3(n))*(L5-L2) sin(angle1(n)-angle2(n))*L5];
    MatrixB=[-N-T/L1*sin(3/2*pi-angle1(n));
       -T/L1*cos(3/2*pi-angle1(n));
       -N*real(G(n)-H(n));
       -T/L1*sin(pi/2-angle1(n)+angle2(n))*L5];
    MatrixC=inv(MatrixA)*MatrixB;
    f(n)=MatrixC(1);
    F4(n)=MatrixC(2);
    F3(n)=MatrixC(3);
    F1(n)=MatrixC(4);
end

plot(f),axis([0 6284 0 20])