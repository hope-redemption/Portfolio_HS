angle1=0:0.001:2*pi;
l1=7.5;
l2=18.86;
l3=18.19;
l4=18.1;
l5=39.6;
l6=33.14;
l7=22.2;
l8=65;
l9=2.02;
l10=14.38;

A=l4-l1*cos(angle1);
B=-l1*sin(angle1);
C=(A.^2+B.^2+l3^2-l2^2)/(2*l3);
%求∠3和角2
angle3=2*atan((B+(A.^2+B.^2-C.^2).^0.5)./(A-C));
angle2=atan((B+l3*sin(angle3))./(A+l3*cos(angle3)));

%求解五联杆
angle52=atan(l10/l9);
A1=(2*l1*l3*cos(angle1)+2*l2*l3*cos(angle2)-2*l3*l5*cos(angle52));
B1=(2*l1*l3*sin(angle1)+2*l2*l3*sin(angle2)-2*l3*l5*sin(angle52));
C1=l1^2+l2^2+l3^2+l5^2-l4^2+2*l1*l2*cos(angle1-angle2)-2*l1*l5*cos(angle1-angle52)-2*l2*l5*cos(angle2-angle52);
angle32=2*atan((B1+(A1.^2+B1.^2-C1.^2).^(0.5))./(A1-C1));
%求出五联杆的∠3

H=l1*exp(j*angle1)+l5*exp(j*angle2)+l8*exp(j*(pi-angle32));
D=4.5*exp(j*angle1)+18.19*exp(j*angle2);



x=real(H);
y=imag(H);
A=65.92/180*pi;


huanzuobiaoxi=[cos(A) -sin(A); sin(A) cos(A)]*[x;y];


figure;
x1=zeros(1,6284);
for n=1:6284
    x1(n)=huanzuobiaoxi(1,n);
end
y1=zeros(1,6284);
for n=1:6284
    y1(n)=huanzuobiaoxi(2,n);
end
plot(x1,y1);