% compute the rotation matrix 
% since the angle about each leg is phi,we can construct the rotation matrix

function RT=rot(phi)

RT=[cos(phi),sin(phi),0;
    -sin(phi),cos(phi),0;
    0,0,1];