% This program shows the trajectory of a hexapod robot animation
clear
clc

Hex_Trajectory
% Joints_GF_Array contains all the joint position in Hex_Trajectory.m

for K=1:size(Joints_GF_Array,2)/4 %Trajectory


%% getting the data
Joints_GF=Joints_GF_Array(1:18,4*K-3:4*K);% Make an array of all points in each configuration for every 4 coloumns.
%% Plot Hexapod===========================================================
figure(1)


for i=1:6
    h=plot3(Joints_GF(3*i-2,:),Joints_GF(3*i-1,:),Joints_GF(3*i,:),'-o','Linewidth',2,...
        'MarkerEdgeColor','k',...
                'MarkerFaceColor','c',...
                'MarkerSize',5);
    hold on
end

for i=1:6
h=plot3([Joints_GF(1,1),Joints_GF(4,1),Joints_GF(7,1),...
    Joints_GF(10,1),Joints_GF(13,1),Joints_GF(16,1),Joints_GF(1,1)],...
    [Joints_GF(2,1),Joints_GF(5,1),Joints_GF(8,1),...
    Joints_GF(11,1),Joints_GF(14,1),Joints_GF(17,1),Joints_GF(2,1)],...
    [Joints_GF(3,1),Joints_GF(6,1),Joints_GF(9,1),...
    Joints_GF(12,1),Joints_GF(15,1),Joints_GF(18,1),Joints_GF(3,1)],...
    'k','Linewidth',3);
    
end
hold off
axis equal
axis manual
grid on
BJ=[[Joints_GF(1,1),Joints_GF(4,1),Joints_GF(7,1),...
    Joints_GF(10,1),Joints_GF(13,1),Joints_GF(16,1),Joints_GF(1,1)];...
    [Joints_GF(2,1),Joints_GF(5,1),Joints_GF(8,1),...
    Joints_GF(11,1),Joints_GF(14,1),Joints_GF(17,1),Joints_GF(2,1)];...
    [Joints_GF(3,1),Joints_GF(6,1),Joints_GF(9,1),...
    Joints_GF(12,1),Joints_GF(15,1),Joints_GF(18,1),Joints_GF(3,1)]];% Body joints in ground frame

text(BJ(1,1),BJ(2,1),BJ(3,1)+1,'#1')
text(BJ(1,2),BJ(2,2),BJ(3,2)+1,'#2')
text(BJ(1,3),BJ(2,3),BJ(3,3)+1,'#3')
text(BJ(1,4),BJ(2,4),BJ(3,4)+1,'#4')
text(BJ(1,5),BJ(2,5),BJ(3,5)+1,'#5')
text(BJ(1,6),BJ(2,6),BJ(3,6)+1,'#6')

xlabel ' X(cm) '
ylabel ' Y(cm) '
zlabel ' Z(cm) '   
title 'Trajectory of Six legged Walking Robot'
pause(0.1)
F(K)=getframe; % Snapshut the plot
end