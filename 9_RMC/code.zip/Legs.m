function LEGS_inv = Legs(t)
global Ltip_JF l0 l1 l2 lt lc lf 

% Ltip_JF is 3x6 matrix 
% object: let LEGS_inv = 0 !!!
t1=t(1,1:6)';
t2=t(2,1:6)';
t3=t(3,1:6)';

for i=1:6    
    x=Ltip_JF(1,i); % Ltip_JF first row is x axis
    y=Ltip_JF(2,i); % Ltip_JF first row is y axis
    z=Ltip_JF(3,i); % Ltip_JF first row is z axis
    % Matrices are stored in columns   
    
        LEGS_inv(3*i-2)=t1(i)-atan2(y,x); % calculate angle difference between current theta 1 and optimization theata 1 
        c=((x-l0*cos(t1(i)))^2+(y-l0*sin(t1(i)))^2+z^2)^.5; % calculate the distance between joint 1 and joint 3
        B=acos((-l2^2+l1^2+c^2)/(2*l1*c)); % calculate angle between l1 and c
        LEGS_inv(3*i-1)=t2(i)-(asin(-z/c)-B); % calculate angle difference between current theta 2 and optimization theata 2 
        %  asin(-z/c)-B : calculate angle of theta2
        C1=pi/2-B;
        h=l1*sin(B);
        C2=acos(h/l2);
        % C1+C2 : angle between l1 and l2
        % pi-C1-C2: angle of theta 3
        LEGS_inv(3*i)=t3(i)-(pi-C1-C2); % calculate angle difference between current theta 3 and optimization theata 3 
        
%         LEGS_inv(3*i-2)=cos(t1(i))*(lc+lf*cos(t2(i))+lt*cos(t2(i)+t3(i)))-x;
%         LEGS_inv(3*i-1)=sin(t1(i))*(lc+lf*cos(t2(i))+lt*cos(t2(i)+t3(i)))-y;
%         LEGS_inv(3*i)=-lf*sin(t2(i))-lt*sin(t3(i)+t2(i))-z;
%         
end

