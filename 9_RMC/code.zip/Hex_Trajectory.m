% find the Trajectory of Hexapod Walking Robot

clc
clear all
%% INITIALIZING THE PROBLEM ==============================
global l0 l1 l2 lt lf lc 

% l0=2.5;%cm
% l1=7.4;%cm
% l2=11.4;%cm
l0=2;%cm
l1=6;%cm
l2=9;%cm
lc=l0;
lf=l1;
lt=l2;

P=zeros(3,1);  % center of the body
% h=7.87;%cm % Radios of platform
h=7.6;%cm % Radios of platform
P1=P+[h*sin(pi/6);h*cos(pi/6);0];
P2=P+[h;0;0];
P3=P+[h*sin(pi/6);-h*cos(pi/6);0];
P4=P+[-h*sin(pi/6);-h*cos(pi/6);0];
P5=P+[-h;0;0];
P6=P+[-h*sin(pi/6);h*cos(pi/6);0];
P_MB=[P1,P2,P3,P4,P5,P6]; % construct the main body, and shows the leg begin position
% The edges of the body where limbs begin in main bodie's frame

% Giving a sample legs tips position:
Q1=[7.5000;12.9904;0];% this give the position of the P1 leg tip
%Q1=[8;13.8564;0];% this give the position of the P1 leg tip
phi=[0,pi/3,2*pi/3,pi,4*pi/3,5*pi/3]; % the angle between Pi is 60°
for i=1:6
Q2(:,i)=(rot(phi(i))*Q1); 
% multiply rotation matrix with the Qi to get each leg tip position
end
%% TRAJECTORY:
steps=20;
OPPz=10*ones(1,steps);
OPPx=zeros(1,steps);
OPPy=zeros(1,steps);
YAW=zeros(1,steps);% around Z
ROLL=zeros(1,steps);% around Y
PITCH=zeros(1,steps);% around X
LTIP=[Q2,Q2,Q2,Q2,Q2];
for q=1:steps
    YAW(q)=(9/200)*(q*2*pi/steps);
end
OPP=[OPPx;OPPy;OPPz];
k=1;

while k<=steps
%% Configuration =========================================================
OP=OPP(1:3,k); % the position of the frame of main body from ground frame.
Ltip=Q2;
yaw=YAW(k);% around Z
roll=ROLL(k);% around Y
pitch=PITCH(k);% around X
%% Define Legs tip in Main body frame====================================

Trn_op=TrnoP(yaw,roll,pitch,-OP);
for i=1:6
    Ltip_MB(1:4,i)=Trn_op*[Ltip(1:3,i);1];
end
Ltip_MB=Ltip_MB(1:3,:);

%% solving inverse Kinematic Problem===========================
% first we should define the X,Y,Z distance of the leg tip from the leg frame positioned on the body ( P1,P2...)

Ltip_JF=Ltip_MB-P_MB; % Leg tip in Joint Frame
global Ltip_JF
[t,fval,exitflag]=fsolve('Legs',zeros(3,6));
if exitflag==1
t1=t(1,1:6)';
t2=t(2,1:6)';
t3=t(3,1:6)';
t_array(1:3,6*k-5:6*k)=t;

%% Find All the Robots joint configuration in Main Body Frame=============
% every 3 rows denote the x,y,z coordinates of the joints from body to end point on the ground.

for i=1:6
Joints_MB(3*i-2:3*i,1:4)=[P_MB(1,i),...
    P_MB(1,i)+lc*cos(t1(i)),...
    P_MB(1,i)+lc*cos(t1(i))+lf*cos(t2(i))*cos(t1(i)),...
    P_MB(1,i)+cos(t1(i))*(lc+lf*cos(t2(i))+lt*cos(t2(i)+t3(i)));...
    P_MB(2,i),...
    P_MB(2,i)+lc*sin(t1(i)),...
    P_MB(2,i)+sin(t1(i))*(lc+lf*cos(t2(i))),...
    P_MB(2,i)+sin(t1(i))*(lc+lf*cos(t2(i))+lt*cos(t2(i)+t3(i)));...
    P_MB(3,i),...
    P_MB(3,i),...
    P_MB(3,i)-lf*sin(t2(i)),...
    P_MB(3,i)-lf*sin(t2(i))-lt*sin(t3(i)+t2(i))];
end

%% define all the points back into the ground coordinate==================
Trn_po=TrnoP_inv(yaw,roll,pitch,-OP);
for i=1:6
for j=1:4
    J1=Trn_po*[Joints_MB(3*i-2:3*i,j);1];
    J1=J1(1:3);
    Joints_GF(3*i-2:3*i,j)=J1;
end
end
Joints_GF_Array(1:18,4*k-3:4*k)=Joints_GF;% Make an array of all points in each configuration for every 4 coloumns.


end
k=k+1;
end


if size(Joints_GF_Array,2)/4==size(OPP,2)
    clc
    disp('Inverese Kinematic for given trajectory is solved.')
    disp('the results of inverse kinematic solution is saved in t_array matrix, every 6 coloumns refers to each step.')
else
    clc 
    disp('The robot reached some singular points')
    disp('The solved solution in other points are saved into t_array matrix in workspace variables.')
t_array;
end