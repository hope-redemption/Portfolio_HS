% shows the trajectory animation of hexapod robot



for K=1:size(Joints_GF_Array,2)/4 %Trajectory


%% getting the data
Joints_GF=Joints_GF_Array(1:18,4*K-3:4*K);% Make an array of all points in each configuration for every 4 coloumns.
%% Plot Hexapod===========================================================
figure(1)
Pthyln=-20:10:TotStp*Vy*delta_t/steps+20;
Pthxln=zeros(size(Pthyln));
Pthzln=zeros(size(Pthyln));
plot3(Pthxln,Pthyln,Pthzln,'-->b','MarkerEdgeColor','r','MarkerSize',7)

hold on
plot3(20,-20,0,-20,0,20,'w')
for i=1:6
    h=plot3(Joints_GF(3*i-2,:),Joints_GF(3*i-1,:),Joints_GF(3*i,:),'-o','Linewidth',2,...
        'MarkerEdgeColor','k',...
                'MarkerFaceColor','c',...
                'MarkerSize',5);
end

for i=1:6
h=plot3([Joints_GF(1,1),Joints_GF(4,1),Joints_GF(7,1),...
    Joints_GF(10,1),Joints_GF(13,1),Joints_GF(16,1),Joints_GF(1,1)],...
    [Joints_GF(2,1),Joints_GF(5,1),Joints_GF(8,1),...
    Joints_GF(11,1),Joints_GF(14,1),Joints_GF(17,1),Joints_GF(2,1)],...
    [Joints_GF(3,1),Joints_GF(6,1),Joints_GF(9,1),...
    Joints_GF(12,1),Joints_GF(15,1),Joints_GF(18,1),Joints_GF(3,1)],...
    'k','Linewidth',3);
    
end

start_Points=[-15,50,3
              -15,14,3
               15,14,3];
end_Points=[-15,14,3
             15,14,3
             15,50,3];
X=[start_Points(:,1)  end_Points(:,1)]'; 
Y=[start_Points(:,2)  end_Points(:,2)]';
Z=[start_Points(:,3)  end_Points(:,3)]';    
line(X,Y,Z);
start_Points1=[-10,50,3
              -10,14,3
               10,14,3];
end_Points1=[-10,14,3
             10,14,3
             10,50,3];
X1=[start_Points1(:,1)  end_Points1(:,1)]'; 
Y1=[start_Points1(:,2)  end_Points1(:,2)]';
Z1=[start_Points1(:,3)  end_Points1(:,3)]';    
line(X1,Y1,Z1);

start_Points2=[-7.5,50,3
              -7.5,14,3
               7.5,14,3];
end_Points2=[-7.5,14,3
             7.5,14,3
             7.5,50,3];
X2=[start_Points2(:,1)  end_Points2(:,1)]'; 
Y2=[start_Points2(:,2)  end_Points2(:,2)]';
Z2=[start_Points2(:,3)  end_Points2(:,3)]';    
line(X2,Y2,Z2);

start_Points3=[-5,50,3
              -5,14,3
               5,14,3];
end_Points3=[-5,14,3
             5,14,3
             5,50,3];
X3=[start_Points3(:,1)  end_Points3(:,1)]'; 
Y3=[start_Points3(:,2)  end_Points3(:,2)]';
Z3=[start_Points3(:,3)  end_Points3(:,3)]';    
line(X3,Y3,Z3);

start_Points21=[-15,14,0
              -15,14,3
               15,14,3];
end_Points21=[-15,14,3
             15,14,3
             15,14,0];
X21=[start_Points21(:,1)  end_Points21(:,1)]'; 
Y21=[start_Points21(:,2)  end_Points21(:,2)]';
Z21=[start_Points21(:,3)  end_Points21(:,3)]';    
line(X21,Y21,Z21);

start_Points22=[-10,14,0
              -10,14,3
               10,14,3];
end_Points22=[-10,14,3
             10,14,3
             10,14,0];
X22=[start_Points22(:,1)  end_Points22(:,1)]'; 
Y22=[start_Points22(:,2)  end_Points22(:,2)]';
Z22=[start_Points22(:,3)  end_Points22(:,3)]';    
line(X22,Y22,Z22);

start_Points23=[-7.5,14,0
              -7.5,14,3
               7.5,14,3];
end_Points23=[-7.5,14,3
             7.5,14,3
             7.5,14,0];
X23=[start_Points23(:,1)  end_Points23(:,1)]'; 
Y23=[start_Points23(:,2)  end_Points23(:,2)]';
Z23=[start_Points23(:,3)  end_Points23(:,3)]';    
line(X23,Y23,Z23);

start_Points24=[-5,14,0
              -5,14,3
               5,14,3];
end_Points24=[-5,14,3
             5,14,3
             5,14,0];
X24=[start_Points24(:,1)  end_Points24(:,1)]'; 
Y24=[start_Points24(:,2)  end_Points24(:,2)]';
Z24=[start_Points24(:,3)  end_Points24(:,3)]';    
line(X24,Y24,Z24);

start_Points11=[-15,-20,0
              -15,14,0
               15,14,0];
end_Points11=[-15,14,0
             15,14,0
             15,-20,0];
X11=[start_Points11(:,1)  end_Points11(:,1)]'; 
Y11=[start_Points11(:,2)  end_Points11(:,2)]';
Z11=[start_Points11(:,3)  end_Points11(:,3)]';    
line(X11,Y11,Z11);

start_Points11=[-15,-20,0
              -15,14,0
               15,14,0];
end_Points11=[-15,14,0
             15,14,0
             15,-20,0];
X11=[start_Points11(:,1)  end_Points11(:,1)]'; 
Y11=[start_Points11(:,2)  end_Points11(:,2)]';
Z11=[start_Points11(:,3)  end_Points11(:,3)]';    
line(X11,Y11,Z11);

start_Points12=[-10,-20,0
              -10,14,0
               10,14,0];
end_Points12=[-10,14,0
             10,14,0
             10,-20,0];
X12=[start_Points12(:,1)  end_Points12(:,1)]'; 
Y12=[start_Points12(:,2)  end_Points12(:,2)]';
Z12=[start_Points12(:,3)  end_Points12(:,3)]';    
line(X12,Y12,Z12);

start_Points13=[-7.5,-20,0
              -7.5,14,0
               7.5,14,0];
end_Points13=[-7.5,14,0
             7.5,14,0
             7.5,-20,0];
X13=[start_Points13(:,1)  end_Points13(:,1)]'; 
Y13=[start_Points13(:,2)  end_Points13(:,2)]';
Z13=[start_Points13(:,3)  end_Points13(:,3)]';    
line(X13,Y13,Z13);

start_Points14=[-5,-20,0
              -5,14,0
               5,14,0];
end_Points14=[-5,14,0
             5,14,0
             5,-20,0];
X14=[start_Points14(:,1)  end_Points14(:,1)]'; 
Y14=[start_Points14(:,2)  end_Points14(:,2)]';
Z14=[start_Points14(:,3)  end_Points14(:,3)]';    
line(X14,Y14,Z14);



hold off
axis equal
axis manual
grid on
BJ=[[Joints_GF(1,1),Joints_GF(4,1),Joints_GF(7,1),...
    Joints_GF(10,1),Joints_GF(13,1),Joints_GF(16,1),Joints_GF(1,1)];...
    [Joints_GF(2,1),Joints_GF(5,1),Joints_GF(8,1),...
    Joints_GF(11,1),Joints_GF(14,1),Joints_GF(17,1),Joints_GF(2,1)];...
    [Joints_GF(3,1),Joints_GF(6,1),Joints_GF(9,1),...
    Joints_GF(12,1),Joints_GF(15,1),Joints_GF(18,1),Joints_GF(3,1)]];% Body joints in ground frame

text(BJ(1,1),BJ(2,1),BJ(3,1)+1,'#1')
text(BJ(1,2),BJ(2,2),BJ(3,2)+1,'#2')
text(BJ(1,3),BJ(2,3),BJ(3,3)+1,'#3')
text(BJ(1,4),BJ(2,4),BJ(3,4)+1,'#4')
text(BJ(1,5),BJ(2,5),BJ(3,5)+1,'#5')
text(BJ(1,6),BJ(2,6),BJ(3,6)+1,'#6')

xlabel ' X(cm) '
ylabel ' Y(cm) '
zlabel ' Z(cm) '   
title 'Trajectory of Six legged Walking Robot'
F(K)=getframe; % Snapshut the plot
end

%% Showing the animation of the TRAJECTORY

%movie(F,2,10)
